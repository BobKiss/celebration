<?php
/**
* Template Name: Wish List disabled (пока)
*
* @package WordPress
* @subpackage Twenty_Fourteen
* @since Twenty Fourteen 1.0
*/
get_header();

?>

<div class="template_wrapper wishListTemplate">




</div>

<?php

get_footer();
